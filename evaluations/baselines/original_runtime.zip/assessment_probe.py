import json
from pathlib import Path
from dataclasses import replace, asdict
from servicepilot.agent import ServiceAgent
from servicepilot.graph_runtime import LangGraphServiceRuntime
from servicepilot.repository import InMemoryCommerceRepository
from servicepilot.retrieval import PolicyRetriever
from servicepilot.models import OrderStatus
ROOT=Path(__file__).resolve().parents[2]
class Repo(InMemoryCommerceRepository):
    def __init__(self, orders):
        super().__init__(orders); self.calls=[]; self.mode=''
    def create_refund_request(self, **kw):
        self.calls.append(dict(kw))
        if self.mode=='race':
            self._orders[kw['order_id']]=replace(self._orders[kw['order_id']],status=OrderStatus.SHIPPED)
        r=super().create_refund_request(**kw)
        if self.mode=='lost': raise TimeoutError('injected response loss after commit')
        return r

def run(name, follow='确认', mode='', change=None):
    repo=Repo.from_json(ROOT/'data/orders.json')
    agent=ServiceAgent(repo, PolicyRetriever.from_json(ROOT/'data/policies.json'))
    graph=LangGraphServiceRuntime(agent)
    first=graph.chat(user_id='USER-001', message='我要退掉 ORD-1001')
    if change: repo._orders['ORD-1001']=replace(repo._orders['ORD-1001'],**change)
    repo.mode=mode
    second=graph.chat(user_id='USER-001',message=follow,session_id=first.session.session_id)
    return dict(case=name,response=second.message,intent=second.session.intent.value,pending=second.session.pending_action,refund_calls=repo.calls,refund_records=repo._refund_requests,order=asdict(repo._orders['ORD-1001']),events=[asdict(e) for e in second.events])
rows=[run('switch_plain','改成换货'),run('switch_with_confirm','确认改成换货'),run('response_lost',mode='lost'),run('status_between_turns',change={'status':OrderStatus.SHIPPED}),run('status_at_write',mode='race'),run('amount_changed',change={'amount':599.0})]
print(json.dumps(rows,ensure_ascii=False,indent=2))
