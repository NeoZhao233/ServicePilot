from __future__ import annotations

import argparse
from pathlib import Path

from .agent import ServiceAgent
from .graph_runtime import LangGraphServiceRuntime
from .memory import (
    FallbackSessionStore,
    InMemorySessionStore,
    RedisSessionStore,
    SQLiteSessionStore,
)
from .providers import (
    APIEmbeddingEncoder,
    OnlineModelSettings,
    ResponsesIntentModel,
    ResponsesPolicyReranker,
    UrllibJsonTransport,
)
from .repository import InMemoryCommerceRepository
from .retrieval import (
    AdvancedHybridPolicyRetriever,
    BM25PolicyRetriever,
    ChromaPolicyRetriever,
    FastEmbedTextEncoder,
    HashingTextEncoder,
    HybridPolicyRetriever,
    load_policy_chunks,
)
from .routing import (
    CachedVotingIntentRouter,
    EmbeddingIntentRouter,
    LLMIntentRouter,
    RuleIntentRouter,
)


def build_agent(
    data_dir: Path,
    *,
    session_db: Path | None = None,
    online: bool = False,
    use_graph: bool = True,
    chroma_dir: Path | None = None,
    redis_url: str | None = None,
) -> ServiceAgent | LangGraphServiceRuntime:
    repository = InMemoryCommerceRepository.from_json(data_dir / "orders.json")
    store = SQLiteSessionStore(session_db) if session_db else None
    if redis_url:
        store = FallbackSessionStore(
            RedisSessionStore.from_url(redis_url),
            store or InMemorySessionStore(),
        )
    chunks = load_policy_chunks(data_dir / "policies.json")
    if online:
        settings = OnlineModelSettings.from_env()
        transport = UrllibJsonTransport(settings)
        if settings.embedding_mode == "api":
            encoder = APIEmbeddingEncoder(transport, settings.embedding_model)
        elif settings.embedding_mode == "local":
            encoder = FastEmbedTextEncoder(settings.embedding_model)
        else:
            encoder = HashingTextEncoder()
        vector = (
            ChromaPolicyRetriever(chunks, encoder, persist_directory=chroma_dir)
            if chroma_dir
            else HybridPolicyRetriever.from_json(data_dir / "policies.json", encoder=encoder).vector
        )
        router = CachedVotingIntentRouter(
            (
                (
                    "llm",
                    LLMIntentRouter(ResponsesIntentModel(transport, settings.intent_model)),
                    0.5,
                ),
                ("embedding", EmbeddingIntentRouter(encoder), 0.2),
                ("keyword", RuleIntentRouter(), 0.3),
            )
        )
    else:
        encoder = HashingTextEncoder()
        vector = (
            ChromaPolicyRetriever(chunks, encoder, persist_directory=chroma_dir)
            if chroma_dir
            else HybridPolicyRetriever.from_json(data_dir / "policies.json").vector
        )
        router = CachedVotingIntentRouter(
            (
                ("embedding", EmbeddingIntentRouter(encoder), 0.2),
                ("keyword", RuleIntentRouter(), 0.8),
            )
        )
    reranker = ResponsesPolicyReranker(transport, settings.intent_model) if online else None
    retriever = AdvancedHybridPolicyRetriever(
        BM25PolicyRetriever(chunks), vector, reranker=reranker
    )
    agent = ServiceAgent(repository, retriever, router=router, session_store=store)
    return LangGraphServiceRuntime(agent) if use_graph else agent


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the ServicePilot terminal demo")
    parser.add_argument("--user", default="USER-001")
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=Path(__file__).resolve().parents[2] / "data",
    )
    parser.add_argument("--session-db", type=Path, help="SQLite path for durable sessions")
    parser.add_argument("--session-id", help="Resume a session stored in --session-db")
    parser.add_argument(
        "--online", action="store_true", help="Use configured LLM and Embedding APIs"
    )
    parser.add_argument("--legacy-runtime", action="store_true", help="Disable LangGraph workflow")
    parser.add_argument("--chroma-dir", type=Path, help="Persist the vector index in Chroma")
    parser.add_argument("--redis-url", help="Redis URL for TTL-backed short-term memory")
    args = parser.parse_args()
    agent = build_agent(
        args.data_dir,
        session_db=args.session_db,
        online=args.online,
        use_graph=not args.legacy_runtime,
        chroma_dir=args.chroma_dir,
        redis_url=args.redis_url,
    )
    session_id: str | None = args.session_id

    print("ServicePilot 已启动。输入 quit 退出。")
    while True:
        message = input("你：").strip()
        if message.lower() in {"quit", "exit"}:
            break
        response = agent.chat(user_id=args.user, message=message, session_id=session_id)
        session_id = response.session.session_id
        print(f"客服：{response.message}")
        print(f"会话：{session_id}")
        if response.citations:
            print(f"政策依据：{', '.join(response.citations)}")


if __name__ == "__main__":
    main()
