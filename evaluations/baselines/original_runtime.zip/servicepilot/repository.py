from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

from .models import Order, OrderStatus, ToolResult


class InMemoryCommerceRepository:
    """A deterministic stand-in for order, logistics, refund, and ticket services."""

    def __init__(self, orders: list[Order]) -> None:
        self._orders = {order.order_id: order for order in orders}
        self._refund_requests: dict[str, dict[str, str]] = {}
        self._tickets: dict[str, dict[str, str]] = {}

    @classmethod
    def from_json(cls, path: str | Path) -> InMemoryCommerceRepository:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        orders = [
            Order(
                order_id=item["order_id"],
                user_id=item["user_id"],
                product_name=item["product_name"],
                category=item["category"],
                amount=float(item["amount"]),
                status=OrderStatus(item["status"]),
                days_since_delivery=item.get("days_since_delivery"),
                logistics_status=item.get("logistics_status"),
            )
            for item in payload
        ]
        return cls(orders)

    def get_order(self, *, order_id: str, user_id: str) -> ToolResult:
        order = self._orders.get(order_id)
        if order is None:
            return ToolResult(ok=False, error="订单不存在")
        if order.user_id != user_id:
            return ToolResult(ok=False, error="无权查看该订单")
        return ToolResult(
            ok=True,
            data={
                "order_id": order.order_id,
                "product_name": order.product_name,
                "category": order.category,
                "amount": order.amount,
                "status": order.status.value,
                "days_since_delivery": order.days_since_delivery,
                "logistics_status": order.logistics_status,
            },
        )

    def create_refund_request(self, *, order_id: str, user_id: str, reason: str) -> ToolResult:
        lookup = self.get_order(order_id=order_id, user_id=user_id)
        if not lookup.ok:
            return lookup
        if order_id in self._refund_requests:
            return ToolResult(ok=True, data=self._refund_requests[order_id])

        request_id = f"REF-{len(self._refund_requests) + 1:04d}"
        record = {"request_id": request_id, "order_id": order_id, "reason": reason}
        self._refund_requests[order_id] = record
        self._orders[order_id] = replace(self._orders[order_id], status=OrderStatus.REFUNDING)
        return ToolResult(ok=True, data=record)

    def create_ticket(self, *, order_id: str, user_id: str, description: str) -> ToolResult:
        lookup = self.get_order(order_id=order_id, user_id=user_id)
        if not lookup.ok:
            return lookup
        key = f"{order_id}:{description}"
        if key in self._tickets:
            return ToolResult(ok=True, data=self._tickets[key])
        ticket_id = f"TICKET-{len(self._tickets) + 1:04d}"
        record = {"ticket_id": ticket_id, "order_id": order_id, "description": description}
        self._tickets[key] = record
        return ToolResult(ok=True, data=record)
