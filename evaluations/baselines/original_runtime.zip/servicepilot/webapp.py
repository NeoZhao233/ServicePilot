from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field

from .cli import build_agent


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    user_id: str = Field(min_length=1, max_length=128)
    message: str = Field(min_length=1, max_length=20_000)
    session_id: str | None = Field(default=None, max_length=128)


def serialize_response(response) -> dict[str, Any]:
    return {
        "session_id": response.session.session_id,
        "message": response.message,
        "intent": response.session.intent.value,
        "order_id": response.session.order_id,
        "pending_action": response.session.pending_action,
        "citations": list(response.citations),
        "events": [
            {"type": event.event_type, "name": event.name, "detail": event.detail}
            for event in response.events
        ],
    }


def serialize_session(state, events=None) -> dict[str, Any]:
    last_assistant = next(
        (turn["content"] for turn in reversed(state.turns) if turn.get("role") == "assistant"),
        "新会话",
    )
    payload = {
        "session_id": state.session_id,
        "user_id": state.user_id,
        "intent": state.intent.value,
        "order_id": state.order_id,
        "pending_action": state.pending_action,
        "turn_count": sum(turn.get("role") == "user" for turn in state.turns),
        "last_message": last_assistant,
        "turns": state.turns,
    }
    if events is not None:
        payload["events"] = [
            {"type": event.event_type, "name": event.name, "detail": event.detail}
            for event in events
        ]
    return payload


def create_app(
    *,
    data_dir: Path,
    session_db: Path | None = None,
    online: bool = False,
    chroma_dir: Path | None = None,
    redis_url: str | None = None,
) -> FastAPI:
    agent = build_agent(
        data_dir,
        session_db=session_db,
        online=online,
        chroma_dir=chroma_dir,
        redis_url=redis_url,
    )
    assets_dir = Path(__file__).resolve().parent / "web_assets"
    app = FastAPI(
        title="ServicePilot API",
        version="0.1.0",
        description="Policy-grounded e-commerce after-sales Agent API",
    )

    @app.get("/api/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.post("/api/chat")
    def chat(request: ChatRequest) -> dict[str, Any]:
        try:
            response = agent.chat(
                user_id=request.user_id.strip(),
                message=request.message.strip(),
                session_id=request.session_id,
            )
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return serialize_response(response)

    @app.get("/api/sessions")
    def list_sessions(
        user_id: str = Query(min_length=1, max_length=128),
    ) -> dict[str, object]:
        return {
            "sessions": [
                serialize_session(item) for item in agent.list_sessions(user_id.strip())
            ]
        }

    @app.get("/api/sessions/{session_id}")
    def get_session(
        session_id: str,
        user_id: str = Query(min_length=1, max_length=128),
    ) -> dict[str, Any]:
        state = agent.get_session(session_id)
        if state is None:
            raise HTTPException(status_code=404, detail="会话不存在")
        if state.user_id != user_id.strip():
            raise HTTPException(status_code=403, detail="无权访问该会话")
        events = agent.get_events(session_id, user_id=user_id.strip())
        return serialize_session(state, events)

    @app.get("/", response_class=FileResponse)
    def index() -> FileResponse:
        return FileResponse(assets_dir / "index.html", media_type="text/html")

    @app.get("/app.js", response_class=FileResponse)
    def javascript() -> FileResponse:
        return FileResponse(assets_dir / "app.js", media_type="text/javascript")

    @app.get("/styles.css", response_class=FileResponse)
    def stylesheet() -> FileResponse:
        return FileResponse(assets_dir / "styles.css", media_type="text/css")

    return app


def main() -> None:
    project_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description="Run the ServicePilot FastAPI app")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--data-dir", type=Path, default=project_root / "data")
    parser.add_argument(
        "--session-db",
        type=Path,
        default=project_root / ".servicepilot" / "sessions.sqlite3",
    )
    parser.add_argument("--redis-url", help="Redis URL with automatic SQLite fallback")
    parser.add_argument("--online", action="store_true")
    parser.add_argument(
        "--chroma-dir",
        type=Path,
        default=project_root / ".servicepilot" / "chroma",
    )
    args = parser.parse_args()
    app = create_app(
        data_dir=args.data_dir,
        session_db=args.session_db,
        online=args.online,
        chroma_dir=args.chroma_dir,
        redis_url=args.redis_url,
    )
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
