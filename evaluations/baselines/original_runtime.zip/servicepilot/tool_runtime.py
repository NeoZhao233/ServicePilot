from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass

from .models import ToolResult


@dataclass(frozen=True)
class ToolExecution:
    result: ToolResult
    attempts: int
    circuit_open: bool = False


class ToolExecutor:
    """Centralized retries and a small per-tool circuit breaker."""

    def __init__(
        self,
        *,
        max_retries: int = 1,
        failure_threshold: int = 3,
        recovery_seconds: float = 30.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if max_retries < 0:
            raise ValueError("max_retries cannot be negative")
        if failure_threshold <= 0:
            raise ValueError("failure_threshold must be positive")
        self.max_retries = max_retries
        self.failure_threshold = failure_threshold
        self.recovery_seconds = recovery_seconds
        self.clock = clock
        self._failures: dict[str, int] = {}
        self._opened_at: dict[str, float] = {}

    def execute(self, name: str, operation: Callable[[], ToolResult]) -> ToolExecution:
        if self._is_open(name):
            return ToolExecution(
                result=ToolResult(ok=False, error="服务熔断中，请稍后重试"),
                attempts=0,
                circuit_open=True,
            )

        last_result = ToolResult(ok=False, error="工具执行失败")
        for attempt in range(1, self.max_retries + 2):
            try:
                last_result = operation()
            except (ConnectionError, TimeoutError) as exc:
                last_result = ToolResult(ok=False, error=f"{type(exc).__name__}: {exc}")
            except Exception as exc:  # the boundary must not crash the conversation runtime
                last_result = ToolResult(ok=False, error=f"unexpected tool error: {exc}")
                self._record_failure(name)
                return ToolExecution(result=last_result, attempts=attempt)

            if last_result.ok:
                self._failures[name] = 0
                self._opened_at.pop(name, None)
                return ToolExecution(result=last_result, attempts=attempt)
            if attempt <= self.max_retries:
                continue

        self._record_failure(name)
        return ToolExecution(result=last_result, attempts=self.max_retries + 1)

    def _record_failure(self, name: str) -> None:
        failures = self._failures.get(name, 0) + 1
        self._failures[name] = failures
        if failures >= self.failure_threshold:
            self._opened_at[name] = self.clock()

    def _is_open(self, name: str) -> bool:
        opened_at = self._opened_at.get(name)
        if opened_at is None:
            return False
        if self.clock() - opened_at >= self.recovery_seconds:
            self._opened_at.pop(name, None)
            self._failures[name] = 0
            return False
        return True
