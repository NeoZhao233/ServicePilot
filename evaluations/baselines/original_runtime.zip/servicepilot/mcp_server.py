from __future__ import annotations

import argparse
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from .repository import InMemoryCommerceRepository
from .retrieval import (
    AdvancedHybridPolicyRetriever,
    BM25PolicyRetriever,
    HashingTextEncoder,
    VectorPolicyRetriever,
    load_policy_chunks,
)
from .rules import evaluate_refund


def create_mcp_server(data_dir: Path) -> FastMCP:
    repository = InMemoryCommerceRepository.from_json(data_dir / "orders.json")
    chunks = load_policy_chunks(data_dir / "policies.json")
    retriever = AdvancedHybridPolicyRetriever(
        BM25PolicyRetriever(chunks),
        VectorPolicyRetriever(chunks, HashingTextEncoder()),
    )
    server = FastMCP(
        "ServicePilot",
        instructions="电商售后工具服务。所有订单工具必须传入已认证的 user_id。",
    )

    @server.tool(description="查询当前用户拥有的订单；禁止跨用户读取。")
    def get_order(order_id: str, user_id: str) -> dict[str, object]:
        result = repository.get_order(order_id=order_id, user_id=user_id)
        if not result.ok:
            raise ValueError(result.error)
        return result.data

    @server.tool(description="从售后政策库进行混合检索，并返回可引用的政策 ID。")
    def search_policy(query: str, category: str | None = None, limit: int = 3) -> list[dict]:
        return [
            {
                "policy_id": hit.chunk.policy_id,
                "title": hit.chunk.title,
                "content": hit.chunk.content,
                "score": round(hit.score, 6),
            }
            for hit in retriever.search(query, category=category, limit=min(max(limit, 1), 5))
        ]

    @server.tool(description="经用户明确确认后创建退款申请；工具内部再次校验订单归属和规则。")
    def create_refund_request(
        order_id: str,
        user_id: str,
        reason: str,
        user_confirmed: bool,
    ) -> dict[str, object]:
        if not user_confirmed:
            raise ValueError("退款属于敏感操作，缺少用户明确确认")
        lookup = repository.get_order(order_id=order_id, user_id=user_id)
        if not lookup.ok:
            raise ValueError(lookup.error)
        decision = evaluate_refund(lookup.data, damaged=False)
        if not decision.eligible or decision.requires_human:
            raise ValueError(decision.reason)
        result = repository.create_refund_request(
            order_id=order_id,
            user_id=user_id,
            reason=reason,
        )
        if not result.ok:
            raise ValueError(result.error)
        return result.data

    @server.tool(description="为已校验归属的订单创建人工售后工单。")
    def create_ticket(order_id: str, user_id: str, description: str) -> dict[str, object]:
        lookup = repository.get_order(order_id=order_id, user_id=user_id)
        if not lookup.ok:
            raise ValueError(lookup.error)
        result = repository.create_ticket(
            order_id=order_id,
            user_id=user_id,
            description=description,
        )
        if not result.ok:
            raise ValueError(result.error)
        return result.data

    return server


def main() -> None:
    project_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description="Run ServicePilot as an MCP server")
    parser.add_argument("--data-dir", type=Path, default=project_root / "data")
    parser.add_argument(
        "--transport",
        choices=("stdio", "sse", "streamable-http"),
        default="stdio",
    )
    args = parser.parse_args()
    create_mcp_server(args.data_dir).run(transport=args.transport)


if __name__ == "__main__":
    main()
